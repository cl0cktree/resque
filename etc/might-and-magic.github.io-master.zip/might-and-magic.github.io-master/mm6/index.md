---
id: index
title: Might and Magic VI
sidebar_label: MM6
slug: /
---

Comming soon ...
