---
id: index
title: Might and Magic 6, 7, 8 & Merge Fan Website
sidebar_label: Introduction
slug: /
---

Hello!

```js
console.log('f');
```
