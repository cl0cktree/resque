module.exports = {
  sidebar: ['index', 'cheat'],
}
