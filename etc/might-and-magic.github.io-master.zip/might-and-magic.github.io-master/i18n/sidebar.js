module.exports = {
  sidebar: ['index'],
};
